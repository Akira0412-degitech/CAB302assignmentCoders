INSERT INTO users(email, password, role)
VALUES ("testuser@example.com", "testpass", "Student")